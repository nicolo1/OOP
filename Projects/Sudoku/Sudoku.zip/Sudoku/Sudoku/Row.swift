//
//  Row.swift
//  Sudoku
//
//  Created by Tabar, NicoloJanPaez on 2019-02-14.
//  Copyright © 2019 Tabar, NicoloJanPaez. All rights reserved.
//

import Foundation

class Row: WinProtocol {
    var arr: [Cell]
    
    func checkComplete() {
        
    }
    init() {
        
    }
}
