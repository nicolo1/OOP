//
//  Column.swift
//  Sudoku
//
//  Created by Tabar, NicoloJanPaez on 2019-02-14.
//  Copyright © 2019 Tabar, NicoloJanPaez. All rights reserved.
//

import Foundation

class Column: WinProtocol {
    
    let NUM_CELLS = 9
    
    var arr: [Cell]
    
    init() {
        
    }
    
    func checkComplete() {
    
    }
}
