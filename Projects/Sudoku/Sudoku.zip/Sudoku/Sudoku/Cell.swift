//
//  Cell.swift
//  Sudoku
//
//  Created by Tabar, NicoloJanPaez on 2019-02-14.
//  Copyright © 2019 Tabar, NicoloJanPaez. All rights reserved.
//

import Foundation

class Cell {
    let MAX_NUMS = 9
    
    var current_number: Int?
    var solution_number: Int
    
    init(_solution_number: Int) {
        self.solution_number = _solution_number
    }
}
