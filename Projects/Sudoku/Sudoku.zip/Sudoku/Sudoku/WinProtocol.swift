//
//  WinProtocol.swift
//  Sudoku
//
//  Created by Tabar, NicoloJanPaez on 2019-02-14.
//  Copyright © 2019 Tabar, NicoloJanPaez. All rights reserved.
//

import Foundation

protocol WinProtocol {
    var arr: [Cell] { get set }
    
    func checkComplete()
    
    
    
}
