//
//  Grid.swift
//  Sudoku
//
//  Created by Tabar, NicoloJanPaez on 2019-02-14.
//  Copyright © 2019 Tabar, NicoloJanPaez. All rights reserved.
//

import Foundation

class Grid {
    let MAX_BLOCKS = 9
    let MAX_ROWS = 9
    let MAX_COLUMNS = 9
    
    var blocks = [Block]()
    var row = [Row]()
    var column = [Column]()
    
    func solve() {
    
    }
    init() {
        
    }
}
